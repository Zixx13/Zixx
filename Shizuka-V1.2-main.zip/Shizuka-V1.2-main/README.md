# Shizuka-Md WhatsApp Bot V1.2
![alt text](https://github.com/Tanmyname/Shizuka-V1.2/blob/main/Screenshot_20241117-155030~2.png?raw=true?raw=true)
## How to run a Bot on Termux :

**STEP 1**
```
cd $HOME
```
**STEP 2**
```
pkg update -y && pkg upgrade -y && pkg install bash && pkg install git -y && git clone https://github.com/Tanmyname/Shizuka-V1.2.git
```
**STEP 3**
```
cd Shizuka-V1.2
```
**STEP 4**
```
bash run.sh
```
## Support me :) 
<br>
<div align="center">
<a href='https://saweria.co/Supporttann' target='_blank'><img height='64' style='border:0px;height:64px;' src='https://storage.ko-fi.com/cdn/kofi1.png?v=3' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>
</div>
